# Device Management

Work in progress ...

## Extensions

- List
- Create
- Delete
- Get
- Update

## Requests

- List
- Initiate
- Delete
- Get
- Get Status